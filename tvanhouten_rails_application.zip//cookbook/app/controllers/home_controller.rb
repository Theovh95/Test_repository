class HomeController < ApplicationController
  def index
    @number_of_recipes = Recipe.count
  end

  def about
    @title = "About"
  end

  def contact
    @number_of_comments = 0
  end
end
