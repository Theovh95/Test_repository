#numbers = [first_number, second_number, third_number]

puts "This program adds three numbers."

print "enter the first number and press enter:"

first_number = gets


print "enter the second number and press enter:"

second_number = gets

prints "enter the third number and press enter:"

third_number = gets

numbers.chop!

numbers.to_i
#first_number.chop!
#second_number.chop!
#third_number.chop!

#first_number = first_number.to_i
#second_number = second_number.to_i
#third_number = third_number.to_i

sum = first_number + second_number + third_number

message =  "The sum of #{first_number} + #{second_number} + #{third_number} is #{sum}"