class Item < ActiveRecord::Base
end
